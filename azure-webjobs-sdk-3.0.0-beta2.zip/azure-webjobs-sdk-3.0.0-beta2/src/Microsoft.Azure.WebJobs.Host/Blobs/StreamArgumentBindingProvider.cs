﻿// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the MIT License. See License.txt in the project root for license information.

using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs.Host.Bindings;
using Microsoft.Azure.WebJobs.Host.Blobs.Bindings;
using Microsoft.Azure.WebJobs.Host.Storage.Blob;

namespace Microsoft.Azure.WebJobs.Host.Blobs
{
    internal class StreamArgumentBindingProvider : IBlobArgumentBindingProvider
    {
        private readonly IContextGetter<IBlobWrittenWatcher> _blobWrittenWatcherGetter;
        private readonly FileAccess? _defaultAccess;

        public StreamArgumentBindingProvider(IContextGetter<IBlobWrittenWatcher> blobWrittenWatcherGetter)
        {
            if (blobWrittenWatcherGetter == null)
            {
                throw new ArgumentNullException("blobWrittenWatcherGetter");
            }

            _blobWrittenWatcherGetter = blobWrittenWatcherGetter;
        }

        public StreamArgumentBindingProvider(FileAccess defaultAccess)
        {
            _defaultAccess = defaultAccess;
        }

        public FileAccess? DefaultAccess
        {
            get { return _defaultAccess; }
        }

        public IBlobArgumentBinding TryCreate(ParameterInfo parameter, FileAccess? attributeAccess)
        {
            if (parameter.ParameterType != typeof(Stream))
            {
                return null;
            }

            FileAccess? actualAccess = attributeAccess.HasValue ? attributeAccess : DefaultAccess;
            if (!actualAccess.HasValue)
            {
                throw new InvalidOperationException(String.Format(CultureInfo.CurrentCulture,
                    "FileAccess must be specified when binding the parameter '{0}' to a blob Stream. " +
                    "Add a FileAccess argument to the BlobAttribute constructor " +
                    @"(for example, [Blob(""..."", FileAccess.Read)]).",
                    parameter.Name));
            }

            switch (actualAccess.Value)
            {
                case FileAccess.ReadWrite:
                    throw new InvalidOperationException("Cannot bind blob to Stream using FileAccess ReadWrite.");
                case FileAccess.Read:
                    return new ReadStreamArgumentBinding();
                case FileAccess.Write:
                default:
                    return new WriteStreamArgumentBinding(_blobWrittenWatcherGetter);
            }
        }

        private class ReadStreamArgumentBinding : IBlobArgumentBinding
        {
            public FileAccess Access
            {
                get { return FileAccess.Read; }
            }

            public Type ValueType
            {
                get { return typeof(Stream); }
            }

            public async Task<IValueProvider> BindAsync(IStorageBlob blob, ValueBindingContext context)
            {
                WatchableReadStream watchableStream = await ReadBlobArgumentBinding.TryBindStreamAsync(blob, context);
                if (watchableStream == null)
                {
                    return BlobValueProvider.CreateWithNull<Stream>(blob);
                }

                return new BlobWatchableDisposableValueProvider(blob, watchableStream, typeof(Stream),
                    watcher: watchableStream, disposable: watchableStream);
            }
        }

        private class WriteStreamArgumentBinding : IBlobArgumentBinding
        {
            private readonly IContextGetter<IBlobWrittenWatcher> _blobWrittenWatcherGetter;

            public WriteStreamArgumentBinding(IContextGetter<IBlobWrittenWatcher> blobWrittenWatcherGetter)
            {
                if (blobWrittenWatcherGetter == null)
                {
                    throw new ArgumentNullException("blobWrittenWatcherGetter");
                }

                _blobWrittenWatcherGetter = blobWrittenWatcherGetter;
            }

            public FileAccess Access
            {
                get { return FileAccess.Write; }
            }

            public Type ValueType
            {
                get { return typeof(Stream); }
            }

            public async Task<IValueProvider> BindAsync(IStorageBlob blob, ValueBindingContext context)
            {
                WatchableCloudBlobStream watchableStream = await WriteBlobArgumentBinding.BindStreamAsync(blob,
                    context, _blobWrittenWatcherGetter.Value);
                return new WriteStreamValueBinder(blob, watchableStream);
            }

            // There's no way to dispose a CloudBlobStream without committing.
            // This class intentionally does not implement IDisposable because there's nothing it can do in Dispose.
            private sealed class WriteStreamValueBinder : IValueBinder, IWatchable
            {
                private readonly IStorageBlob _blob;
                private readonly WatchableCloudBlobStream _stream;

                public WriteStreamValueBinder(IStorageBlob blob, WatchableCloudBlobStream stream)
                {
                    _blob = blob;
                    _stream = stream;
                }

                public Type Type
                {
                    get { return typeof(Stream); }
                }

                public IWatcher Watcher
                {
                    get { return _stream; }
                }

                public Task<object> GetValueAsync()
                {
                    return Task.FromResult<object>(_stream);
                }

                public async Task SetValueAsync(object value, CancellationToken cancellationToken)
                {
                    Debug.Assert(value == null || value == await GetValueAsync(),
                        "The value argument should be either the same instance as returned by GetValueAsync() or null");

                    // Not ByRef, so can ignore value argument.

                    // Determine whether or not to upload the blob.
                    if (await _stream.CompleteAsync(cancellationToken))
                    {
                        _stream.Dispose(); // Can only dispose when committing; see note on class above.
                    }
                }

                public string ToInvokeString()
                {
                    return _blob.GetBlobPath();
                }
            }
        }
    }
}
